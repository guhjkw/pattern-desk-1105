/* TradingView side. TradingView has no market-data API for this kind of use, so the engine reads
   prices from the brokers' own feeds and treats TradingView as the charting screen and an
   (optional) alert trigger: a Pine Script indicator watches the chart and, when a double top or
   bottom breaks its neckline, sends a webhook. Webhooks need a paid TradingView plan with 2FA on,
   must answer within about 3 seconds, and are not retried, so the server answers at once and does
   the work after.

   parse() turns that webhook into the SAME signal object the backtest produces (stop and target
   recomputed here with the engine's rules), so a live alert and a backtested trade are sized and
   routed by one code path. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./patterns.js'));
  else root.TvAlert = factory(root.PatternEngine);
})(typeof self !== 'undefined' ? self : this, function (P) {
  'use strict';

  var EXCHANGES = { NSE: 'NSE', BSE: 'NSE', NASDAQ: 'US', NYSE: 'US', ARCA: 'US', AMEX: 'US', BATS: 'US', CBOE: 'US' };

  /* The Pine Script v6 indicator, with the engine's current settings baked in as input defaults. */
  function pine(cfg) {
    var c = P.cfgOf(cfg);
    return [
      '//@version=6',
      '// Pattern Desk: double top / double bottom alerts for the Pattern Desk server.',
      '// Create ONE alert on this indicator: condition "Any alert() function call", "Once per bar close", webhook URL = your server /tv.',
      '// The secret input is hidden from the chart legend. Not yet compiled in TradingView: milestone 2 checks it on your charts.',
      'indicator("Pattern Desk alerts", overlay = true, max_bars_back = 500, max_labels_count = 200)',
      '',
      'pivotLen = input.int(' + c.pivot + ', "Pivot bars each side", minval = 1)',
      'tolPct   = input.float(' + c.tolerancePct + ', "Tops within %", step = 0.05)',
      'minGap   = input.int(' + c.minGap + ', "Min bars between tops", minval = 2)',
      'maxGap   = input.int(' + c.maxGap + ', "Max bars between tops")',
      'minDepth = input.float(' + c.minDepthPct + ', "Min neckline depth %", step = 0.05)',
      'maxWait  = input.int(' + c.maxBarsToBreak + ', "Bars to break the neckline")',
      'volMult  = input.float(' + c.volumeMult + ', "Breakout volume x 20-bar average (0 = off)", step = 0.1)',
      'mode     = input.string("day", "Mode", options = ["day", "swing"])',
      'secret   = input.string("", "Webhook secret", display = display.none)',
      '',
      'ph = ta.pivothigh(high, pivotLen, pivotLen)',
      'pl = ta.pivotlow(low, pivotLen, pivotLen)',
      'avgVol = ta.sma(volume, 20)[1]',
      '',
      'var float h1 = na',
      'var int   h1i = na',
      'var float l1 = na',
      'var int   l1i = na',
      'var float topNeck = na',
      'var float topExt = na',
      'var float topSwing = na',
      'var int   topArmed = na',
      'var float botNeck = na',
      'var float botExt = na',
      'var float botSwing = na',
      'var int   botArmed = na',
      '',
      'send(string kind, string side, float neck, float ext, float swingLvl) =>',
      '    msg = \'{"secret":"\' + secret + \'","strategy":"\' + kind + \'","symbol":"\' + syminfo.ticker + \'","exchange":"\' + syminfo.prefix + \'","tf":"\' + timeframe.period + \'","mode":"\' + mode + \'","side":"\' + side + \'","close":\' + str.tostring(close) + \',"neckline":\' + str.tostring(neck) + \',"extreme":\' + str.tostring(ext) + \',"swing":\' + str.tostring(swingLvl) + \',"volume":\' + str.tostring(volume) + \',"avgVolume":\' + str.tostring(nz(avgVol)) + \',"time":\' + str.tostring(time_close) + \',"id":"\' + syminfo.ticker + "-" + str.tostring(time_close) + "-" + kind + \'"}\'',
      '    alert(msg, alert.freq_once_per_bar_close)',
      '',
      '// 1. a new swing high: does it make a double top with the previous one?',
      'if not na(ph)',
      '    p2i = bar_index - pivotLen',
      '    if not na(h1) and p2i - h1i >= minGap and p2i - h1i <= maxGap and math.abs(ph - h1) / h1 * 100 <= tolPct',
      '        ext = math.max(ph, h1)',
      '        neck = low[pivotLen + 1]',
      '        poke = false',
      '        for k = pivotLen + 1 to bar_index - h1i - 1',
      '            neck := math.min(neck, low[k])',
      '            poke := poke or high[k] > ext',
      '        if not poke and (ext - neck) / ext * 100 >= minDepth and close > neck',
      '            topNeck := neck',
      '            topExt := ext',
      '            topSwing := na',
      '            topArmed := bar_index',
      '    h1 := ph',
      '    h1i := p2i',
      '',
      'if not na(pl)',
      '    q2i = bar_index - pivotLen',
      '    if not na(l1) and q2i - l1i >= minGap and q2i - l1i <= maxGap and math.abs(pl - l1) / l1 * 100 <= tolPct',
      '        ext2 = math.min(pl, l1)',
      '        neck2 = high[pivotLen + 1]',
      '        poke2 = false',
      '        for k = pivotLen + 1 to bar_index - l1i - 1',
      '            neck2 := math.max(neck2, high[k])',
      '            poke2 := poke2 or low[k] < ext2',
      '        if not poke2 and (neck2 - ext2) / ext2 * 100 >= minDepth and close < neck2',
      '            botNeck := neck2',
      '            botExt := ext2',
      '            botSwing := na',
      '            botArmed := bar_index',
      '    l1 := pl',
      '    l1i := q2i',
      '',
      '// 2. armed patterns: break, cancel or expire on the bar close',
      'volOk = volMult <= 0 or volume >= volMult * avgVol',
      'if not na(topArmed) and bar_index > topArmed',
      '    if close > topExt',
      '        topArmed := na',
      '    else if close < topNeck',
      '        if volOk',
      '            send("double_top", "short", topNeck, topExt, na(topSwing) ? topExt : topSwing)',
      '            label.new(bar_index, high, "DT", style = label.style_label_down, color = color.red, textcolor = color.white)',
      '        topArmed := na',
      '    else if bar_index - topArmed > maxWait',
      '        topArmed := na',
      '    else',
      '        topSwing := na(topSwing) ? high : math.max(topSwing, high)',
      '',
      'if not na(botArmed) and bar_index > botArmed',
      '    if close < botExt',
      '        botArmed := na',
      '    else if close > botNeck',
      '        if volOk',
      '            send("double_bottom", "long", botNeck, botExt, na(botSwing) ? botExt : botSwing)',
      '            label.new(bar_index, low, "DB", style = label.style_label_up, color = color.green, textcolor = color.white)',
      '        botArmed := na',
      '    else if bar_index - botArmed > maxWait',
      '        botArmed := na',
      '    else',
      '        botSwing := na(botSwing) ? low : math.min(botSwing, low)',
      ''
    ].join('\n');
  }

  function fail(errors) { return { ok: false, errors: errors }; }

  /* body: the raw webhook text. ctx: { secret, symbols, cfg, seen: {id:true}, nowMs, maxAgeMs } */
  function parse(body, ctx) {
    var a;
    try { a = typeof body === 'string' ? JSON.parse(body) : body; } catch (e) { return fail(['The alert is not valid JSON (check the alert message box in TradingView)']); }
    if (!a || typeof a !== 'object') return fail(['Empty alert']);
    var errs = [];
    if (!ctx.secret || a.secret !== ctx.secret) errs.push('Wrong or missing secret: refused, and logged');
    if (a.strategy !== 'double_top' && a.strategy !== 'double_bottom') errs.push('Unknown strategy "' + a.strategy + '"');
    ['close', 'neckline', 'extreme'].forEach(function (k) { if (typeof a[k] !== 'number' || !isFinite(a[k]) || a[k] <= 0) errs.push(k + ' must be a positive number'); });
    var market = EXCHANGES[String(a.exchange || '').toUpperCase()];
    var sym = (ctx.symbols || []).filter(function (s) { return s.symbol === String(a.symbol || '').toUpperCase() && (!market || s.market === market); })[0];
    if (!sym) errs.push('Symbol ' + (a.exchange ? a.exchange + ':' : '') + a.symbol + ' is not on the watchlist');
    var mode = a.mode === 'swing' || String(a.tf) === '60' || String(a.tf) === '1D' || String(a.tf) === 'D' ? 'swing' : 'day';
    var top = a.strategy === 'double_top';
    if (!errs.length) {
      if (top && !(a.close < a.neckline && a.neckline < a.extreme)) errs.push('Levels do not make a double top (close < neckline < tops)');
      if (!top && !(a.close > a.neckline && a.neckline > a.extreme)) errs.push('Levels do not make a double bottom (close > neckline > bottoms)');
      if (a.side && a.side !== (top ? 'short' : 'long')) errs.push('Side "' + a.side + '" does not match a ' + a.strategy);
    }
    var id = String(a.id || (a.symbol + '-' + a.time + '-' + a.strategy));
    if (!errs.length && ctx.seen && ctx.seen[id]) errs.push('Duplicate alert ' + id + ': already handled (TradingView can fire twice)');
    var t = typeof a.time === 'number' ? a.time : Date.parse(a.time);
    if (!errs.length && ctx.nowMs && ctx.maxAgeMs && isFinite(t) && ctx.nowMs - t > ctx.maxAgeMs) errs.push('Alert is ' + Math.round((ctx.nowMs - t) / 60000) + ' minutes old: too late to act on');
    if (errs.length) return fail(errs);

    var cfg = P.cfgOf(ctx.cfg), tick = sym.tick;
    var level = cfg.stop === 'tops' ? a.extreme : cfg.stop === 'mid' ? (a.extreme + a.neckline) / 2 : (typeof a.swing === 'number' && isFinite(a.swing) ? a.swing : a.extreme);
    var stop = top ? level * (1 + cfg.stopBufferPct / 100) : level * (1 - cfg.stopBufferPct / 100);
    if (top ? stop <= a.close : stop >= a.close) stop = top ? a.extreme * (1 + cfg.stopBufferPct / 100) : a.extreme * (1 - cfg.stopBufferPct / 100);
    var height = Math.abs(a.extreme - a.neckline), risk = Math.abs(stop - a.close);
    var target = cfg.target === 'r' ? (top ? a.close - cfg.targetR * risk : a.close + cfg.targetR * risk) : (top ? a.neckline - height * cfg.targetMult : a.neckline + height * cfg.targetMult);
    var rr = risk > 0 ? Math.abs(target - a.close) / risk : 0;
    if (rr < cfg.minRR) return fail(['Reward is ' + rr.toFixed(2) + 'x risk, under the ' + cfg.minRR + 'x minimum: not traded']);
    var barMin = mode === 'swing' ? 60 : 5;   // TradingView stamps the bar CLOSE; signals carry the bar's start time
    var when = isFinite(t) ? new Date(t - barMin * 60e3 + (sym.market === 'NSE' ? 5.5 : -4) * 3600e3).toISOString() : null;
    if (ctx.seen) ctx.seen[id] = true;
    return { ok: true, signal: {
      id: id, source: 'tradingview', symbol: sym.symbol, market: sym.market, mode: mode, type: a.strategy, side: top ? 'short' : 'long',
      day: when ? when.slice(0, 10) : null, time: when ? when.slice(11, 16) : null,
      entry: P.roundTick(a.close, tick), stop: P.roundTick(stop, tick), target: P.roundTick(target, tick), rr: Math.round(rr * 100) / 100,
      neckline: P.roundTick(a.neckline, tick), height: P.roundTick(height, tick),
      volumeRatio: a.avgVolume ? Math.round(a.volume / a.avgVolume * 100) / 100 : null,
      reason: (top ? 'Double top' : 'Double bottom') + ' alert from TradingView, neckline ' + P.roundTick(a.neckline, tick)
    } };
  }

  /* What TradingView would send for a backtest signal (for the page's "send a test alert" box) */
  function examplePayload(signal, secret, sym) {
    var offset = sym.market === 'NSE' ? 5.5 : -4;
    var t = Date.parse(signal.day + 'T' + signal.time + ':00Z') - offset * 3600e3 + (signal.mode === 'swing' ? 60 : 5) * 60e3;   // bar close time
    var extreme = signal.points ? (signal.side === 'short' ? Math.max(signal.points[0].price, signal.points[1].price) : Math.min(signal.points[0].price, signal.points[1].price)) : signal.stop;
    return JSON.stringify({ secret: secret, strategy: signal.type, symbol: signal.symbol, exchange: sym.market === 'NSE' ? 'NSE' : sym.exchange, tf: signal.mode === 'swing' ? '60' : '5',
      mode: signal.mode, side: signal.side, close: signal.entry, neckline: signal.neckline, extreme: P.roundTick(extreme, sym.tick), swing: signal.stopLevel || null,
      volume: null, avgVolume: null, time: t, id: signal.symbol + '-' + t + '-' + signal.type }, null, 2);
  }

  return { pine: pine, parse: parse, examplePayload: examplePayload, EXCHANGES: EXCHANGES };
});
